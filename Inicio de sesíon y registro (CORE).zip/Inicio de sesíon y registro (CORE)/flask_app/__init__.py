from flask import Flask #type: ignore

app = Flask(__name__)
app.secret_key = 'clave super hiper mega ultra segura'