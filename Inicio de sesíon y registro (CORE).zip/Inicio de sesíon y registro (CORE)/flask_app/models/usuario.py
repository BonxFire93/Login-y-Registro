from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash #type: ignore
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class User:
    db = 'usuarios.db'
    def __init__(self, data):
        self.id = data['id']
        self.nombre = data['nombre']
        self.apellido = data['apellido']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls, data):
        query = 'INSERT INTO usuarios (nombre, apellido, email, password, created_at, updated_at) VALUES ( %(nombre)s, %(apellido)s, %(email)s, %(password)s, NOW(), NOW());'
        tuple_data = (data['nombre'], data['apellido'], data['email'], data['password'], data['created_at'], data['updated_at'])
        return connectToMySQL(cls.db).query_db(query, tuple_data)

    @classmethod
    def get_by_email(cls, email):
        query = 'SELECT * FROM usuarios WHERE email = %(email)s'
        result = connectToMySQL(cls.db).query_db(query, (email))
        if not result:
            return False
        return cls(result[0])

    @classmethod
    def get_by_id(user):
        is_valid = True

        if len(user['nombre']) < 2: #type: ignore
            flash('El nombre debe tener al menos 2 caracteres.', 'register')
            is_valid = False
        elif not user['nombre'].isalpha(): #type: ignore
            flash('el nombre solo debe contener letras', 'register')
            is_valid = False
        
        if len(user['apellido']) < 2: #type: ignore
            flash('El apellido debe tener al menos 2 caracteres.', 'register')
            is_valid = False
        elif not user['apellido'].isalpha(): #type: ignore
            flash('el apellido solo debe contener letras.', 'register')
            is_valid = False

        if not EMAIL_REGEX.match(user['email']): #type: ignore
            flash('Formato de correo electrónico inválido.', 'register')
            is_valid = False
        elif User.get_by_email(user['email']): #type: ignore
            flash('El correo electrónico ya está registrado.', 'register')
            is_valid = False

        if len(user['password']) < 8: #type: ignore
            flash('La contraseña debe tener al menos 8 caracteres.', 'register')
            is_valid = False

        if user['password'] != user['confirm_password']: #type: ignore
            flash('Las contraseñas no coinciden.', 'register')
            is_valid = False

        return is_valid