from flask import render_template, redirect, request, session, flash #type: ignore
from flask_app import app
from flask_app.models.usuario import User

@app.route('/')
def index():
    return render_template('index.html')

@app.route('register', methods = ['POST'])
def register():
    if not User.validate_register(request.form):
        return redirect('/')
    data = {
        'nombre': request.form['nombre'],
        'apellido': request.form['apellido'],
        'email': request.form['email'],
        'password': request.form['password'],
        'created_at': request.form['created_at'],
        'updated_at': request.form['updated_at'],
    }
    user_id = User.save(data)
    session['user_id'] = user_id
    return redirect('/sucess')

@app.route('/login', method=['POST'])
def login():
    user = User.get_by_email(request.form['email'])
    if not user or user.password != request.form['password']:
        flash('El correo o la contraseña son incorrectas.', 'login')
        return redirect('/')

    session['user_id'] = user.id
    return redirect('/success')

@app.route('/success')
def success():
    if 'user_id' not in session:
        flash('Debes inicar sesión primero', 'login')
        return redirect('/')

    current_user = User.get_by_id(session['user_id'])
    return render_template('success.html', user = current_user)

@app.route('/logout')
def logout():
    session.clear()
    return redirect ('/')