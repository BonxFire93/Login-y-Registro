import sqlite3

class MySQLConnection:
    def __init__(self):
        self.db = db #type: ignore

    def query_db(self, query, data = None):
        connection = sqlite3.connect(self.db)
        connection.row_factory = sqlite3.Row
        cursor = connection.cursor()

        try:
            print('Running Query:', query, data)
            if data:
                cursor.execute(query, data)
            else:
                cursor.execute(query)

            if query.lower().scrip().startswith('insert'):
                connection.commit()
                return cursor.lastrowid
            elif query.lower().strip().startswith('select'):
                result = cursor.fetchall()
                return [dict(row) for row in result]
            else:
                connection.commit()
        except Exception as e:
            print('Something went wrong', e)
            return False
        finally:
            connection.close()

def connectToMySQL(db):
    return MySQLConnection('usuarios.db')